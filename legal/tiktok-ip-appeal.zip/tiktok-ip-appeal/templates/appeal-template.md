# TikTok Shop Appeal Template — Design Patent Infringement (USD877,242S)

## Appeal Configuration

**Reason for Appeal:** Misjudgment by platform

**Supporting Images:** Upload the comparison document from `appeal-outputs/`

## Appeal Text Template

Replace all [BRACKETED] sections before submitting:

---

I am appealing this violation as a platform misjudgment. The cited design patent USD877,242S protects only the specific ornamental appearance depicted in its patent drawings — a plain, undecorated card cover with no graphic design elements. My product, "[PRODUCT NAME]," features an entirely original graphic design ([BRIEF DESCRIPTION — e.g., "a novelty pet driver's license layout with custom pet photo and humorous ID fields"]) that bears no visual resemblance whatsoever to the patented design.

Design patent infringement requires that an ordinary observer would find the accused product substantially similar in overall visual impression to the patented design. As shown in the attached side-by-side comparison, my product's ornamental design is clearly and obviously distinct from the patent drawings.

Furthermore, the IP owner has filed identical infringement claims against multiple products in my shop, each featuring completely different original artwork, using the same patent number and identical claim language. This pattern demonstrates the complaints are not based on actual visual comparison between my products and the patent drawings, but rather an overbroad attempt to claim ownership over the entire product category of credit card skins — which is not what a design patent protects.

I have attached comparison images showing the patent drawings alongside my product to demonstrate there is no substantial similarity in ornamental design.

---

## Customization Notes

- Keep the core legal argument (ordinary observer test, ornamental design distinction) in every appeal
- Change only the product name and design description
- The mass-filing paragraph is powerful — always include it if multiple products were hit
- Keep tone professional and factual
- Do NOT use emotional language or accusations of bad faith
- Do NOT make legal threats or reference their litigation history

## Example Customizations

**For pet driver's license skin:**
"...features an entirely original graphic design (a novelty pet driver's license layout with custom photo placement, humorous ID fields, and stylized text) that bears no visual resemblance..."

**For Schmeckles/meme skin:**
"...features an entirely original graphic design (pop culture fan art with custom illustrated characters and stylized currency imagery) that bears no visual resemblance..."

**For solid color/pattern skin:**
"...features an entirely original graphic design (a custom geometric pattern/solid color treatment with [specific design elements]) that bears no visual resemblance..."
