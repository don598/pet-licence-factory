# TikTok Shop IP Appeal Kit — vs. Cucu Inc (USD877,242S)

## What This Is

A complete workflow folder for handling mass design patent takedown claims from Cucu Inc on TikTok Shop. Designed to work with Claude Cowork + Claude in Chrome for semi-automated appeal processing.

## Quick Start

### 1. Set Up the Folder
1. Copy this entire folder to your Desktop (or wherever you want Cowork to access it)
2. Download the patent drawings — follow instructions in `references/patent-drawings/DOWNLOAD.md`
3. Add your product listing images to `product-images/`

### 2. Connect to Cowork
1. Open Claude Desktop app → switch to Cowork mode
2. Point Cowork at this folder
3. Enable Claude in Chrome extension for browser access to TikTok Seller Center

### 3. Run an Appeal
Tell Cowork something like:
- "I have a new IP violation on TikTok Shop. Help me appeal it."
- "Process all pending violations in the appeal log."
- "Generate comparison documents for all products in product-images/"

Cowork will follow the SKILL.md workflow to:
1. Gather violation details (via Chrome if available)
2. Generate side-by-side comparison images
3. Write customized appeal text
4. Submit the appeal (via Chrome if available)
5. Log everything in appeal-log.md

### 4. For New Violations
Each time Cucu files a new takedown:
1. Tell Cowork about the new violation
2. Drop the product image in `product-images/` (or let Chrome grab it)
3. Let Cowork handle the rest

## Folder Structure

```
tiktok-ip-appeal/
├── README.md                   ← You are here
├── SKILL.md                    ← Cowork instructions (the brain)
├── appeal-log.md               ← Running log of all appeals
├── references/
│   ├── patent-info.md          ← Full patent details + legal context
│   └── patent-drawings/        ← USD877,242S figures (download first!)
│       └── DOWNLOAD.md         ← Download URLs and instructions
├── templates/
│   └── appeal-template.md      ← Appeal text template with examples
├── product-images/             ← Your product listing images (add yours here)
└── appeal-outputs/             ← Generated comparison docs + appeal texts
```

## Key URLs

- **TikTok Violations Dashboard:** https://seller-us.tiktok.com/health-center?tab=ncp&click_for=overview
- **Google Patents (USD877,242S):** https://patents.google.com/patent/USD877242S1/en

## Key Dates

- **First violations filed:** March 20, 2026
- **First appeal deadline:** March 25, 2026 11:06 AM
- **TikTok appeal window:** 30 days from violation (1st appeal), 15 days from rejection (2nd appeal)

## Legal Context (TL;DR)

Cucu Inc holds a design patent on a plain card cover shape. They're mass-filing takedowns against all card skin sellers regardless of design similarity. Your products have completely original artwork that looks nothing like their patent drawings. The legal standard for infringement (ordinary observer test) strongly favors you. They've sued two companies before (Slickwraps 2019, Luxx Group 2021) but both cases settled without any court ruling on the patent's validity. Full details in `references/patent-info.md`.
