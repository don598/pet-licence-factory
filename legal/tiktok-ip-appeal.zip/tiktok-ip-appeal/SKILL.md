---
name: tiktok-ip-appeal
description: Automate TikTok Shop design patent infringement appeal responses against Cucu Inc (USD877,242S). Use this skill whenever the user mentions a new IP violation, takedown, patent complaint, or appeal on TikTok Shop related to credit card skins/covers. This skill handles the full workflow - downloading product images, generating side-by-side comparison documents, writing appeal text, and submitting via browser.
---

# TikTok Shop IP Appeal Workflow — Cucu Inc (USD877,242S)

## Background

Cucu Inc (cucucovers.com) holds US Design Patent USD877,242S for a "card cover." They are conducting mass takedown campaigns on TikTok Shop, filing identical design patent infringement claims against all credit card skin/cover products regardless of visual similarity. The patent drawings show a plain, undecorated rectangular card cover with a chip cutout — no graphic design whatsoever.

Our products feature entirely original graphic artwork (pet driver's licenses, meme designs, pop culture references, etc.) that bear zero visual resemblance to the patent drawings. The takedowns are category-based, not design-based.

### Key Patent Details
- **Patent Number:** USD877,242S
- **Patent Owner:** Cucu Inc (Toronto, Canada)
- **Granted:** March 3, 2020
- **Filed:** September 28, 2018
- **Inventors:** Kunal Arneja, Nathaniel Bagnell
- **Claim:** "The ornamental design for a card cover, as shown and described."
- **What it shows:** Two embodiments of a plain card cover from 14 views (perspective, front, back, sides, top, bottom). Broken lines show the card itself and form NO part of the claimed design.
- **Patent drawings location:** `references/patent-drawings/` folder and online at https://patents.google.com/patent/USD877242S1/en

### Legal Basis for Appeal
1. Design patent infringement requires an "ordinary observer" to find the accused product "substantially similar in overall visual impression" to the patented design.
2. The patent protects only the specific ornamental appearance shown in the drawings — NOT the concept of a credit card sticker.
3. Our products have completely different ornamental designs (original artwork) vs. the patent's plain/blank cover.
4. Identical claims filed against visually unrelated products demonstrate the complaints aren't based on actual visual comparison.

## Workflow

### Step 1: Gather Violation Details

**TikTok Shop Violations Dashboard URL:**
https://seller-us.tiktok.com/health-center?tab=ncp&click_for=overview

When a new violation is reported:
1. If Claude in Chrome is available, navigate directly to the URL above (user must be logged in)
2. For each violation, capture:
   - Product name and ID
   - Violation record ID
   - IP Name and Registration Number (should be USD877242S)
   - Appeal deadline
   - Product thumbnail/images
3. Download or screenshot the product listing images
4. Save product images to `product-images/` folder

### Step 2: Generate Comparison Document

Create a side-by-side comparison image for each product:

**Left side:** Patent drawings from `references/patent-drawings/`
- Use FIG. 1 (perspective) and FIG. 2 (front view) as primary comparisons
- Label clearly: "USD877,242S Patent Drawing"

**Right side:** The actual product listing image
- Label clearly: "Our Product: [Product Name]"

**Layout:**
- Clean white background
- Clear labels and headers
- Title: "Design Comparison — Non-Infringement Evidence"
- Add callout text highlighting key visual differences:
  - "Patent shows plain/blank cover with no graphic design"
  - "Our product features original [description] artwork"
  - "No visual similarity in ornamental design"

Save comparison documents to `appeal-outputs/comparison-[product-id].png`

### Step 3: Write Appeal Text

Use this template, customizing the bracketed sections per product:

---

**Reason for Appeal:** Misjudgment by platform

**Appeal Text:**

I am appealing this violation as a platform misjudgment. The cited design patent USD877,242S protects only the specific ornamental appearance depicted in its patent drawings — a plain, undecorated card cover with no graphic design elements. My product, "[PRODUCT NAME]," features an entirely original graphic design ([BRIEF DESCRIPTION OF THE DESIGN]) that bears no visual resemblance whatsoever to the patented design.

Design patent infringement requires that an ordinary observer would find the accused product substantially similar in overall visual impression to the patented design. As shown in the attached side-by-side comparison, my product's ornamental design is clearly and obviously distinct from the patent drawings.

Furthermore, the IP owner has filed identical infringement claims against multiple products in my shop, each featuring completely different original artwork, using the same patent number and identical claim language. This pattern demonstrates the complaints are not based on actual visual comparison between my products and the patent drawings, but rather an overbroad attempt to claim ownership over the entire product category of credit card skins — which is not what a design patent protects.

I have attached comparison images showing the patent drawings alongside my product to demonstrate there is no substantial similarity in ornamental design.

---

Save appeal text to `appeal-outputs/appeal-text-[product-id].txt`

### Step 4: Submit Appeal (via Claude in Chrome)

If browser access is available:
1. Navigate to TikTok Shop Seller Center → Shop Health → Violation Records
2. Click "Appeal" on the target violation
3. Select "Misjudgment by platform" as the reason
4. Upload the comparison image(s) from `appeal-outputs/`
5. Paste the appeal text into the description field
6. Submit the appeal
7. Screenshot the confirmation
8. Log the submission in `appeal-log.md`

### Step 5: Log the Appeal

Append to `appeal-log.md`:

```
## [DATE] - [PRODUCT NAME]
- **Product ID:** [ID]
- **Violation Record ID:** [ID]
- **Appeal Deadline:** [DATE]
- **Appeal Submitted:** [DATE/TIME]
- **Comparison File:** [FILENAME]
- **Status:** Submitted / Pending / Accepted / Rejected
- **Notes:** [Any additional notes]
```

## Batch Processing

When multiple violations exist:
1. List all current violations first
2. Generate all comparison documents
3. Generate all appeal texts
4. Submit all appeals sequentially
5. Log all submissions

## File Structure

```
tiktok-ip-appeal/
├── SKILL.md                    (this file)
├── appeal-log.md               (running log of all appeals)
├── references/
│   ├── patent-drawings/        (USD877,242S figures)
│   └── patent-info.md          (patent details and legal context)
├── templates/
│   └── appeal-template.md      (appeal text template)
├── product-images/             (our product listing images)
└── appeal-outputs/             (generated comparison docs and appeal texts)
```

## Important Notes

- Appeal deadline is typically 5 days from violation date — always check and prioritize by deadline
- TikTok allows up to 2 appeals per violation (first within 30 days, second within 15 days of rejection)
- Always upload comparison images — visual evidence is critical
- Keep appeal text professional and factual, avoid emotional language
- Document everything in the appeal log for future reference
- If an appeal is rejected, the second attempt should include additional evidence (e.g., copyright registration, more detailed design analysis)
