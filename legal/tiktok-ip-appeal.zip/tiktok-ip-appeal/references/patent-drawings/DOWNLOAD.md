# Patent Drawing Download Instructions

Network access isn't available in this environment, so please download these patent drawing images and place them in this folder.

## Required Downloads

Save these files into the `references/patent-drawings/` folder:

1. **Overview sheet** (all figures):
   https://patentimages.storage.googleapis.com/f7/86/ae/72e3ce77d04bd6/USD0877242-20200303-D00000.png
   → Save as: `patent-overview.png`

2. **Sheet 1** (FIG. 1 perspective, FIG. 2 front view):
   https://patentimages.storage.googleapis.com/39/d2/36/83d02acadf9ea7/USD0877242-20200303-D00001.png
   → Save as: `patent-sheet1-perspective-front.png`

3. **Sheet 2** (FIG. 3-7: back, sides, top, bottom):
   https://patentimages.storage.googleapis.com/48/af/39/16c311da059d2d/USD0877242-20200303-D00002.png
   → Save as: `patent-sheet2-back-sides.png`

4. **Sheet 3** (FIG. 8-9: second embodiment perspective and front):
   https://patentimages.storage.googleapis.com/69/77/c7/a84bb1027e0e14/USD0877242-20200303-D00003.png
   → Save as: `patent-sheet3-embodiment2.png`

5. **Sheet 4** (FIG. 10-14: second embodiment remaining views):
   https://patentimages.storage.googleapis.com/57/98/f6/c36eaa27c2e43d/USD0877242-20200303-D00004.png
   → Save as: `patent-sheet4-embodiment2-views.png`

6. **Full patent PDF**:
   https://patentimages.storage.googleapis.com/9b/ed/60/290ce281281f5c/USD877242.pdf
   → Save as: `USD877242.pdf`

## Automated Download (for Cowork/Chrome)

If using Cowork with Claude in Chrome, ask Claude to navigate to each URL and download the images. Or use this terminal command if curl is available:

```bash
cd references/patent-drawings/
curl -o patent-overview.png "https://patentimages.storage.googleapis.com/f7/86/ae/72e3ce77d04bd6/USD0877242-20200303-D00000.png"
curl -o patent-sheet1-perspective-front.png "https://patentimages.storage.googleapis.com/39/d2/36/83d02acadf9ea7/USD0877242-20200303-D00001.png"
curl -o patent-sheet2-back-sides.png "https://patentimages.storage.googleapis.com/48/af/39/16c311da059d2d/USD0877242-20200303-D00002.png"
curl -o patent-sheet3-embodiment2.png "https://patentimages.storage.googleapis.com/69/77/c7/a84bb1027e0e14/USD0877242-20200303-D00003.png"
curl -o patent-sheet4-embodiment2-views.png "https://patentimages.storage.googleapis.com/57/98/f6/c36eaa27c2e43d/USD0877242-20200303-D00004.png"
curl -o USD877242.pdf "https://patentimages.storage.googleapis.com/9b/ed/60/290ce281281f5c/USD877242.pdf"
```
