# USD877,242S — Patent Reference

## Patent Overview
- **Number:** USD877,242S (US Design Patent)
- **Title:** Card Cover
- **Owner:** Cucu Inc (Toronto, Canada)
- **Inventors:** Kunal Arneja, Nathaniel Bagnell
- **Filed:** September 28, 2018
- **Granted:** March 3, 2020
- **Expiration:** March 3, 2035
- **Status:** Active
- **Attorney:** Perry + Currier Inc.

## The Claim
"The ornamental design for a card cover, as shown and described."

This is a single-claim design patent. It protects ONLY the ornamental appearance shown in the patent drawings — nothing more.

## Patent Drawings Summary
The patent contains 14 figures across 4 drawing sheets showing two embodiments:

**First Embodiment (FIG. 1-7):**
- FIG. 1: Perspective view
- FIG. 2: Front view
- FIG. 3: Back view
- FIG. 4: Left-side view
- FIG. 5: Right-side view
- FIG. 6: Top view
- FIG. 7: Bottom view

**Second Embodiment (FIG. 8-14):**
- FIG. 8: Perspective view
- FIG. 9: Front view
- FIG. 10: Back view
- FIG. 11-14: Side, top, bottom views

**Critical note:** "The broken line showing of portions of the card cover is included for the purpose of illustrating environmental structure and forms no part of the claimed design."

This means the card itself (shown in broken lines) is NOT protected. Only the solid-line portions — the cover shape — are claimed.

## What the Drawings Show
Both embodiments depict a plain, undecorated rectangular cover shaped to fit a standard credit/debit card. There is a cutout for the chip area. There are NO graphic designs, patterns, text, images, or decorative elements on the cover surface.

## Cucu Inc's Other Patents
- D801,430 — Card applique
- D833,527 — Card applique
- D835,714 — Card applique
- D837,877 — Card applique
- Plus several Canadian design registrations

## Known Litigation History
1. **Cucu Inc v. Slickwraps Inc** (2019) — District of Wyoming (Case 2:2019cv00119). Likely settled. Slickwraps went out of business in 2020.
2. **Cucu Inc v. Luxx Group Inc et al** (2021) — Eastern District of New York (Case 2:2021cv01834). Likely settled. No public ruling or opinion.

Neither case produced a published court opinion on infringement or patent validity. The patent has never been tested in a contested trial.

## Key Legal Arguments for Non-Infringement
1. **No visual similarity:** Our products feature original graphic artwork completely different from the plain/blank patent drawings.
2. **Ordinary observer test:** No reasonable observer would confuse our decorated card skins with the undecorated cover shown in the patent.
3. **Mass filing pattern:** Identical claims against visually unrelated products demonstrate bad-faith enforcement, not legitimate infringement claims.
4. **Functionality doctrine:** The basic card-cover shape (rectangle with chip cutout) is dictated by function, not ornamental choice — a potential invalidity argument if needed.

## Online Resources
- Google Patents: https://patents.google.com/patent/USD877242S1/en
- Patent PDF: https://patentimages.storage.googleapis.com/9b/ed/60/290ce281281f5c/USD877242.pdf
- Patent Drawings: https://patentimages.storage.googleapis.com/39/d2/36/83d02acadf9ea7/USD0877242-20200303-D00001.png
- Cucu Covers website: https://cucucovers.com
- Cucu patent notice page: https://cucucovers.com/pages/patent-notice
