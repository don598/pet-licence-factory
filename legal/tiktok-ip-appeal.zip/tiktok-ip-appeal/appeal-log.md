# TikTok Shop IP Appeal Log

## Summary
- **Claimant:** Cucu Inc
- **Patent:** USD877,242S (Card Cover)
- **Platform:** TikTok Shop
- **First Violation Date:** 03/20/2026
- **Appeal Deadline:** 03/25/2026

---

## Pending Appeals

### 2026-03-20 — Custom Pet Drivers License Credit Card Cover
- **Product ID:** 1730588997623976283
- **Violation Record ID:** 7619381246405493006
- **Appeal Deadline:** 03/25/2026 11:06 AM
- **Appeal Submitted:** PENDING
- **Comparison File:** PENDING
- **Status:** Not appealed
- **Notes:** First violation discovered. Pet driver's license design.

### 2026-03-20 — Schmeckles Credit Card Skin
- **Product ID:** 1729456584807387483
- **Appeal Deadline:** TBD (check Seller Center)
- **Appeal Submitted:** PENDING
- **Comparison File:** PENDING
- **Status:** Not appealed
- **Notes:** Rick and Morty Schmeckles currency design.

---

## Submitted Appeals

(None yet)

---

## Resolved Appeals

(None yet)
